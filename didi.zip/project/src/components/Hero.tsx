import React, { useState } from 'react';
import { ArrowRight, FileText } from 'lucide-react';

const Hero = () => {
  const [isAnimationPaused, setIsAnimationPaused] = useState(false);

  return (
    <section className="min-h-screen bg-gradient-to-br from-[#FE751F] via-[#FFF4E6] to-white relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute top-20 left-10 w-32 h-32 bg-[#0DB86A] rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-20 right-20 w-48 h-48 bg-[#FE751F] rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-1/4 w-24 h-24 bg-white rounded-full blur-2xl animate-bounce"></div>
      </div>

      {/* Grid Pattern Overlay */}
      <div className="absolute inset-0 opacity-10" style={{
        backgroundImage: `linear-gradient(rgba(26, 26, 26, 0.1) 1px, transparent 1px),
                         linear-gradient(90deg, rgba(26, 26, 26, 0.1) 1px, transparent 1px)`,
        backgroundSize: '40px 40px'
      }}></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center min-h-screen pt-16">
          {/* Left Content */}
          <div className="space-y-8">
            <div className="space-y-4">
              <div className="flex items-center space-x-2 text-2xl">
                <span>🐸</span>
                <span className="font-bold text-[#1A1A1A]">$DiDi</span>
              </div>
              
              <h1 className="text-5xl lg:text-7xl font-bold leading-tight">
                <span className="bg-gradient-to-r from-[#FE751F] to-[#0DB86A] bg-clip-text text-transparent">
                  The Frog Who Rides
                </span>
              </h1>
              
              <h2 className="text-3xl lg:text-4xl font-bold text-[#FE751F] animate-pulse">
                Ride to Earn
              </h2>
              
              <p className="text-xl text-[#1A1A1A] max-w-lg leading-relaxed">
                Why pay for rides when you could earn while moving? Join the revolution against corporate ride-sharing giants.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <button className="group bg-[#0DB86A] hover:bg-[#059669] text-white px-8 py-4 rounded-lg font-semibold text-lg transition-all duration-300 transform hover:scale-105 hover:shadow-xl flex items-center justify-center space-x-2">
                <span>Join the Ride</span>
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform duration-300" />
              </button>
              
              <button className="group bg-transparent border-2 border-[#1A1A1A] text-[#1A1A1A] hover:bg-[#1A1A1A] hover:text-white px-8 py-4 rounded-lg font-semibold text-lg transition-all duration-300 flex items-center justify-center space-x-2">
                <FileText className="w-5 h-5" />
                <span>Whitepaper</span>
              </button>
            </div>

            {/* Trust Indicators */}
            <div className="flex flex-wrap gap-4 pt-4">
              <div className="bg-white/60 backdrop-blur-sm px-4 py-2 rounded-full border">
                <span className="text-sm font-medium text-[#1A1A1A]">✅ LP Burned</span>
              </div>
              <div className="bg-white/60 backdrop-blur-sm px-4 py-2 rounded-full border">
                <span className="text-sm font-medium text-[#1A1A1A]">✅ Ownership Renounced</span>
              </div>
              <div className="bg-white/60 backdrop-blur-sm px-4 py-2 rounded-full border">
                <span className="text-sm font-medium text-[#1A1A1A]">✅ Audit Complete</span>
              </div>
            </div>
          </div>

          {/* Right Visual */}
          <div className="relative">
            <div className="relative z-10">
              {/* Animated Frog Car */}
              <div className={`text-9xl transform transition-all duration-1000 ${
                isAnimationPaused ? '' : 'animate-bounce'
              }`}>
                🚗💨
              </div>
              
              {/* Floating Elements */}
              <div className="absolute -top-8 -left-8 text-4xl animate-spin">🪙</div>
              <div className="absolute -bottom-4 -right-4 text-3xl animate-pulse">⚡</div>
              <div className="absolute top-1/2 -left-12 text-2xl animate-bounce delay-500">💰</div>
              
              {/* Interactive Brake Button */}
              <button
                onClick={() => setIsAnimationPaused(!isAnimationPaused)}
                className="absolute -bottom-16 left-1/2 transform -translate-x-1/2 bg-red-500 hover:bg-red-600 text-white px-6 py-3 rounded-lg font-bold shadow-lg transition-all duration-300 hover:scale-110"
              >
                {isAnimationPaused ? 'START' : 'BRAKE'}
              </button>
            </div>

            {/* Background Glow */}
            <div className="absolute inset-0 bg-gradient-to-r from-[#FE751F]/20 to-[#0DB86A]/20 blur-3xl scale-150"></div>
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <div className="w-6 h-10 border-2 border-[#1A1A1A] rounded-full flex justify-center">
          <div className="w-1 h-3 bg-[#1A1A1A] rounded-full mt-2 animate-pulse"></div>
        </div>
      </div>
    </section>
  );
};

export default Hero;