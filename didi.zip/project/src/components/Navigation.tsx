import React, { useState, useEffect } from 'react';
import { Menu, X, ChevronDown } from 'lucide-react';

const Navigation = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [timeLeft, setTimeLeft] = useState({ days: 21, hours: 4, minutes: 32, seconds: 18 });

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    
    // Countdown timer
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev.seconds > 0) {
          return { ...prev, seconds: prev.seconds - 1 };
        } else if (prev.minutes > 0) {
          return { ...prev, minutes: prev.minutes - 1, seconds: 59 };
        } else if (prev.hours > 0) {
          return { ...prev, hours: prev.hours - 1, minutes: 59, seconds: 59 };
        } else if (prev.days > 0) {
          return { ...prev, days: prev.days - 1, hours: 23, minutes: 59, seconds: 59 };
        }
        return prev;
      });
    }, 1000);

    return () => {
      window.removeEventListener('scroll', handleScroll);
      clearInterval(timer);
    };
  }, []);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setIsMobileMenuOpen(false);
    }
  };

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
      isScrolled 
        ? 'bg-white/80 backdrop-blur-lg shadow-lg' 
        : 'bg-transparent'
    }`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center space-x-2">
            <div className="text-2xl">🐸</div>
            <span className="text-xl font-bold text-[#1A1A1A]">DiDi</span>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            {['About', 'Roadmap', 'Tokenomics', 'Buy', 'FAQ'].map((item) => (
              <button
                key={item}
                onClick={() => scrollToSection(item.toLowerCase())}
                className="text-[#1A1A1A] hover:text-[#FE751F] transition-colors duration-200 font-medium"
              >
                {item}
              </button>
            ))}
            
            {/* Community Dropdown */}
            <div className="relative">
              <button
                onClick={() => setIsDropdownOpen(!isDropdownOpen)}
                className="flex items-center space-x-1 text-[#1A1A1A] hover:text-[#FE751F] transition-colors duration-200 font-medium"
              >
                <span>Community</span>
                <ChevronDown className="w-4 h-4" />
              </button>
              
              {isDropdownOpen && (
                <div className="absolute top-full right-0 mt-2 w-64 bg-white rounded-lg shadow-xl border p-4">
                  <div className="space-y-3">
                    <a href="#" className="flex items-center justify-between p-2 hover:bg-gray-50 rounded">
                      <span>Telegram</span>
                      <span className="text-sm text-[#0DB86A]">8.9K members</span>
                    </a>
                    <a href="#" className="flex items-center justify-between p-2 hover:bg-gray-50 rounded">
                      <span>Twitter/X</span>
                      <span className="text-sm text-[#0DB86A]">15.2K followers</span>
                    </a>
                    <a href="#" className="flex items-center justify-between p-2 hover:bg-gray-50 rounded">
                      <span>Discord</span>
                      <span className="text-xs bg-[#FE751F] text-white px-2 py-1 rounded">Soon</span>
                    </a>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Launch Timer */}
          <div className="hidden md:flex items-center space-x-2 bg-red-500 text-white px-3 py-1 rounded-full text-sm font-medium">
            <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
            <span>{timeLeft.days}d {timeLeft.hours}h {timeLeft.minutes}m {timeLeft.seconds}s</span>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="md:hidden text-[#1A1A1A]"
          >
            {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="md:hidden bg-white border-t mt-2 py-4 space-y-4">
            {['About', 'Roadmap', 'Tokenomics', 'Buy', 'FAQ', 'Community'].map((item) => (
              <button
                key={item}
                onClick={() => scrollToSection(item.toLowerCase())}
                className="block w-full text-left px-4 py-2 text-[#1A1A1A] hover:text-[#FE751F] transition-colors duration-200"
              >
                {item}
              </button>
            ))}
            <div className="px-4 py-2 bg-red-500 text-white rounded text-sm font-medium">
              Launch in: {timeLeft.days}d {timeLeft.hours}h {timeLeft.minutes}m
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navigation;